# BT Sync Module for Boxen

## Usage

```puppet
include btsync
```

## Required Puppet Modules

None.

## Developing

Write code.

Run `script/cibuild`.
