# Harvest Puppet Module for Boxen

A Harvest app installer for Boxen

## Usage

```puppet
include harvest
```

## Required Puppet Modules

* `boxen`
