# Induction Puppet Module for Boxen

Install [Induction](http://inductionapp.com/) via Boxen.

## Usage

```puppet
include induction
```

## Required Puppet Modules

* `boxen`
